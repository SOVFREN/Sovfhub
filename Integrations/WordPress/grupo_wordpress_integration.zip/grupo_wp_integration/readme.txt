=== Grupo Chatroom ===
Contributors: BaeVox
Tags: chat, chat app, chat room, chat script, chatroom, chatting, email, group chat, messaging, radio player, social network
Requires Grupo Version 3.1 or higher
Requires PHP: 7.4 or higher

Integrate Grupo Chat with your WordPress website. This plugin requires Grupo Pro Version >= 3.1
Grupo Pro is a Codecanyon exclusive chat room script which includes a wide range of Features.
This plugin

== Description ==
You now integrate Grupo chat with your WordPress websites easily.
Grupo Pro is a One to One & Group Chat script which includes a wide range of features.
For More Info : https://1.envato.market/N110v

== Installation ==
= From Dashboard ( WordPress Admin ) =
* plugins -> Add New
* Upload \'grupo_wp_integration.zip\'
* Click on Install Now and then Active.

= using FTP or similar =
* Unzip \"grupo_wp_integration.zip\" file and
* Upload \"grupo_wp_integration\" folder to the \"/wp-content/plugins/\" directory.
* Activate the plugin through the \"Plugins\" menu in WordPress.


Login as Wordpress Admin > Click on Settings > Click Integrate Grupo Chat > Enter your Grupo API Secret Key & Grupo Chat Pro Website address


== Frequently Asked Questions ==
Paste the shortcode anywhere inside the pages/posts/widget where you want to embed Grupo Pro.

[embed_grupo_pro load_url="" width="411px" height="650px" open_in_parent_window=false require_wp_login=false]

= Attributes : =
* load_url: Leave empty or specify the Group/Profile (URL) you wish to embed.
* width: The width attribute specifies the height of the embedded content.
* height: The height attribute specifies the height of the embedded content.
* require_wp_login: Whether Wordpress login required to view page [true|false]
* open_in_parent_window: Whether to force Grupo to be opened in the parent window [true|false]

== Changelog ==
= 1.0 =
* Initial release.
